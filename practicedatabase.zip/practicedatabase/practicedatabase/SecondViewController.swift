//
//  SecondViewController.swift
//  pracfmdb
//
//  Created by Yogesh Patel on 14/11/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var arrdata: NSMutableArray!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrdata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:TableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        let reginfo: Reginfo = arrdata.object(at: indexPath.row) as! Reginfo
        
        cell.lblemail.text = "Email \(reginfo.email)"
        cell.lblpassword.text = "Password\(reginfo.password)"
        cell.btnedit.tag = indexPath.row
        cell.btndelete.tag = indexPath.row
        return cell
    }
    

    @IBOutlet var tblview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool)
    {
        self.getalldata()
    }
    func getalldata()
    {
        arrdata = NSMutableArray()
        arrdata =  Modelmanager.getinstance().getallregdata()
        tblview.reloadData()
    }
    @IBAction func btnedit(_ sender: UIButton)
    {
        self.performSegue(withIdentifier: "editsegue", sender: sender)
    }
    @IBAction func btndelete(_ sender: AnyObject)
    {
        let delete :UIButton = sender as! UIButton
        let selectedindex: Int = delete.tag
        let register: Reginfo = arrdata.object(at: selectedindex) as! Reginfo
        let isDeleted = Modelmanager.getinstance().deleteregdata(register)
        if isDeleted
        {
            Util.invokealert("Deleteing Process", strbody: "Record Delete SucessFully", delegate: self)
        }
        else
        {
            Util.invokealert("Deleteing Process", strbody: "Record not  Delete SucessFully", delegate: self)
        }
        self.getalldata()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btninsert(_ sender: UIButton)
    {
        dismiss(animated: true, completion: nil)
    }
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "editsegue")
        {
            let btnEdit : UIButton = sender as! UIButton
            let selectedIndex : Int = btnEdit.tag
            let viewController : ViewController = segue.destination as! ViewController
            viewController.isedit = true
            
            viewController.regdata = arrdata.object(at: selectedIndex) as! Reginfo
        }
    }
    

}
