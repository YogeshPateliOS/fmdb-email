//
//  ViewController.swift
//  pracfmdb
//
//  Created by Yogesh Patel on 14/11/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
 
    @IBOutlet var txtpassword: UITextField!
    
    @IBOutlet var txtemail: UITextField!
    var isedit:Bool = false
    var regdata:Reginfo!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if isedit
        {
            txtemail.text = regdata.email
            txtpassword.text = regdata.password
            }
        // Do any additional setup after loading the view, typically from a nib.
    }

  
    @IBAction func btnsave(_ sender: UIButton)
    {
        if txtemail.text == ""
        {
            Util.invokealert("", strbody: "Please Enter Email", delegate: self)
        }
        else if txtpassword.text == ""
        {
            Util.invokealert("", strbody: "Please Enter Password", delegate: self)
        }
        
        else
        {
            if isedit
            {
                let reginfo: Reginfo = Reginfo()
                reginfo.id = regdata.id
                
                reginfo.email = txtemail.text!
                reginfo.password = txtpassword.text!
                
                let isupdated = Modelmanager.getinstance().updateregdata(reginfo)
                if isupdated
                {
                    Util.invokealert("", strbody: "Updated Sucess", delegate: self)
                }
                else
                {
                     Util.invokealert("", strbody: "Error updated ", delegate: self)
                }
            }
            else
            {
                let reginfo: Reginfo = Reginfo()
               // reginfo.id = regdata.id
                
                reginfo.email = txtemail.text!
                reginfo.password = txtpassword.text!
                
                let isinserted = Modelmanager.getinstance().addregdata(reginfo)
                if isinserted
                {
                    Util.invokealert("", strbody: "Record Inserted successfully.", delegate: self)
                }
                else {
                    Util.invokealert("", strbody: "Error in inserting record.", delegate: self)
                }
            }
            dismiss(animated: true, completion: nil)
            
        }
        
    }
    

}

