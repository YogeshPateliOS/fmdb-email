//
//  Util.swift
//  pracfmdb
//
//  Created by Yogesh Patel on 14/11/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

import UIKit

class Util: NSObject {

    class func getpath(_ filename: String) -> String
    {
        let documenturl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let fileurl = documenturl.appendingPathComponent(filename)
        print("Database Data\(fileurl)")
        return fileurl.path
    }
    
    class func copydatabase(_ filename: NSString)
    {
        let dbpath = getpath(filename as String)
        let filemanager = FileManager.default
        
        if !filemanager.fileExists(atPath: dbpath)
        {
            let urlmain = Bundle.main.resourceURL
            let frompath = urlmain?.appendingPathComponent(filename as String)
            var error:NSError?
            do
            {
                try filemanager.copyItem(atPath: (frompath?.path)!, toPath: dbpath)
                
            }
            catch let error1 as NSError
            {
                error = error1
            }
            let alertview = UIAlertView()
            if error != nil
            {
                alertview.title = "Error"
                alertview.message = error?.localizedDescription
            }
            else
            {
                alertview.title = "Sucess "
                alertview.message = "Sucessfull data are"
            }
            alertview.addButton(withTitle: "OK")
            alertview.delegate = nil
            alertview.show()
            
        }
    }
    
    
    class func invokealert(_ strtitle:NSString, strbody: NSString, delegate: AnyObject)
    {
        let alert:UIAlertView = UIAlertView()
        alert.title = strtitle as String
        alert.message = strbody as String
        alert.delegate = delegate
        alert.addButton(withTitle: "OK")
        alert.show()
    }
    
}
